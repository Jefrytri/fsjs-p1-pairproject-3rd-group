const ipLocation = require('iplocation')

async function getLocation(ip) {
  try {
    const data = await ipLocation(ip)

    return {
      ipAddress: ip,
      city: data.city,
      region: data.region?.name,
      country: data.country?.name
    }
  } catch (err) {
    return {
      ipAddress: ip,
      city: 'Unknown',
      region: 'Unknown',
      country: 'Unknown'
    }
  }
}

module.exports = { getLocation }